import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.sql.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class ManagerManagementPanel extends FlightManagementSystem{
    JFrame manFrame;
    public ManagerManagementPanel() throws SQLException{
        manFrame = new JFrame("MG Portal");
        JLabel welcomeLabel = new JLabel("Manager Management Portal");
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 32));
        welcomeLabel.setBounds(160, 130, 500, 50);
        manFrame.add(welcomeLabel);

        JButton viewManButton = new JButton("View all Managers");
        viewManButton.setBounds(200, 200, 300, 40);
        viewManButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        viewManButton.setFocusPainted(false);
        viewManButton.addActionListener(actionEvent -> {
            try {
                viewManager();
            } catch (SQLException throwable) {
                throwable.printStackTrace();
            }
        });
        manFrame.add(viewManButton);

        JButton addManButton = new JButton("Add a manager");
        addManButton.setBounds(200, 270, 300, 40);
        addManButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        addManButton.setFocusPainted(false);
        addManButton.addActionListener(actionEvent -> {
            try {
                addManager();
            } catch (SQLException throwable) {
                throwable.printStackTrace();
            }
        });
        manFrame.add(addManButton);

        JButton editManButton = new JButton("Edit a manager");
        editManButton.setBounds(200, 340, 300, 40);
        editManButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        editManButton.setFocusPainted(false);
        editManButton.addActionListener(actionEvent -> {
            try {
                editManager();
            } catch (SQLException throwable) {
                throwable.printStackTrace();
            }
        });
        manFrame.add(editManButton);

        JButton deleteManButton = new JButton("Delete a manager");
        deleteManButton.setBounds(200, 410, 300, 40);
        deleteManButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        deleteManButton.setFocusPainted(false);
        deleteManButton.addActionListener(deleteEvent -> {
            deleteManager();
        });
        manFrame.add(deleteManButton);

        JButton exitButton = new JButton("Back");
        exitButton.setBounds(200, 480, 300, 40);
        exitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        exitButton.setFocusPainted(false);

        exitButton.addActionListener(actionEvent -> {
            manFrame.dispose();
            AdminPortal.AdmenuFrame.setVisible(true);

        });
        manFrame.add(exitButton);

        manFrame.setSize(700, 750);
        manFrame.getContentPane().setBackground(new Color(2, 174, 248));
        LineBorder blackBorder = new LineBorder(new Color(1, 25, 86), 7);
        manFrame.getRootPane().setBorder(blackBorder);
        manFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        manFrame.setLayout(null);
        manFrame.setVisible(true);
        manFrame.setLocationRelativeTo(null);
    }

    public void viewManager() throws SQLException{
        manFrame.setVisible(false);

        JFrame frame=new JFrame("Manager Records");
        JPanel panel=new JPanel();
        JdbcConnector jdbcConnector = new JdbcConnector();
        jdbcConnector.connect();
        Connection conn = jdbcConnector.getConnection();
        jdbcConnector.connect();
        Statement statement = conn.createStatement();
        String q = "select * from manager";
        ResultSet resultSet = statement.executeQuery(q);

        while (resultSet.next()) {
            JPanel managerCard = new JPanel();

            JLabel unameLabel = new JLabel("Username");
            unameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel unameVal = new JLabel(resultSet.getString(1));
            unameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel passLabel = new JLabel("Password");
            passLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel passVal = new JLabel(resultSet.getString(2));
            passVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel idLabel = new JLabel("ID");
            idLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel idVal = new JLabel(String.valueOf(resultSet.getInt(3)));
            idVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel nameLabel = new JLabel("Name");
            nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel nameVal = new JLabel(resultSet.getString(4));
            nameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel emailLabel = new JLabel("Email");
            emailLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel emailVal = new JLabel(resultSet.getString(5));
            emailVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel deptLabel = new JLabel("Department");
            deptLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            JLabel deptVal = new JLabel(resultSet.getString(6));
            deptVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

            managerCard.add(unameLabel);
            managerCard.add(unameVal);
            managerCard.add(passLabel);
            managerCard.add(passVal);
            managerCard.add(idLabel);
            managerCard.add(idVal);
            managerCard.add(nameLabel);
            managerCard.add(nameVal);
            managerCard.add(emailLabel);
            managerCard.add(emailVal);
            managerCard.add(deptLabel);
            managerCard.add(deptVal);

            managerCard.setSize(1000, 400);
            managerCard.setBackground(new Color(166, 209, 230));
            managerCard.setBorder(new EmptyBorder(20, 50, 20, 50));
            GridLayout cardLayout = new GridLayout(0, 2);
            cardLayout.setHgap(5);
            cardLayout.setVgap(10);
            managerCard.setLayout(cardLayout);
            panel.add(managerCard);
        }

        JPanel buttonPanel = new JPanel();
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        backButton.setBounds(450, 30, 200,50);
        backButton.setFocusPainted(false);

        backButton.addActionListener(actionListener -> {
            frame.dispose();
            manFrame.setVisible(true);
        });
        buttonPanel.add(backButton);
        buttonPanel.setLayout(null);
        buttonPanel.setBackground(new Color(254, 251, 246));
        panel.add(buttonPanel);


        GridLayout layout = new GridLayout(0, 1);
        layout.setVgap(30);
        panel.setLayout(layout);
        panel.setBackground(new Color(254, 251, 246));
        panel.setBorder(new EmptyBorder(50, 0, 50, 0));

        JScrollPane scrollBar=new JScrollPane(panel,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        frame.add(scrollBar);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1100,750));
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

        resultSet.close();
        statement.close();
        conn.close();
        jdbcConnector.close();
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void addManager() throws SQLException  {

        manFrame.setVisible(false);

        JFrame frame=new JFrame("Manager Records");
        JPanel panel=new JPanel();

        JLabel idLabel = new JLabel("Enter ID");
        idLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField idVal = new JTextField("");
        idVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        idVal.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();
                }
            }
        });

        JLabel unameLabel = new JLabel("Give username");
        unameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField unameVal = new JTextField("");
        unameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel passLabel = new JLabel("Give password");
        passLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField passVal = new JTextField("");
        passVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel nameLabel = new JLabel("Enter Name");
        nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField nameVal = new JTextField("");
        nameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel emailLabel = new JLabel("Enter Email Address");
        emailLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField emailVal = new JTextField("");
        emailVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel deptLabel = new JLabel("Enter Department");
        deptLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField deptVal = new JTextField("");
        deptVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        panel.add(unameLabel);
        panel.add(unameVal);
        panel.add(passLabel);
        panel.add(passVal);
        panel.add(idLabel);
        panel.add(idVal);
        panel.add(nameLabel);
        panel.add(nameVal);
        panel.add(emailLabel);
        panel.add(emailVal);
        panel.add(deptLabel);
        panel.add(deptVal);

        GridLayout cardLayout = new GridLayout(0, 2);
        cardLayout.setHgap(60);
        cardLayout.setVgap(40);
        panel.setLayout(cardLayout);

        panel.setSize(1000, 400);
        panel.setBackground(new Color(166, 209, 230));
        panel.setBorder(new EmptyBorder(20, 50, 20, 50));

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        backButton.setBounds(450, 30, 200,50);
        backButton.setFocusPainted(false);

        backButton.addActionListener(actionListener -> {
            frame.dispose();
            manFrame.setVisible(true);
        });
        panel.add(backButton);

        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        submitButton.setBounds(450, 30, 200,50);
        submitButton.setFocusPainted(false);

        submitButton.addActionListener(actionListener -> {
            JdbcConnector jdbcConnector = new JdbcConnector();
            jdbcConnector.connect();
            Connection conn = jdbcConnector.getConnection();
            jdbcConnector.connect();
            PreparedStatement pstmt = null;
            Statement statement = null;
            try {
                String query = "INSERT INTO manager(username, password, id, name, email, department) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";
                pstmt = conn.prepareStatement(query);

                String uname = unameVal.getText();
                String pass = passVal.getText();
                int id = Integer.parseInt(idVal.getText());
                String name = nameVal.getText();
                String email = emailVal.getText();
                String department = deptVal.getText();

                pstmt.setString(1, uname);
                pstmt.setString(2, pass);
                pstmt.setInt(3, id);
                pstmt.setString(4, name);
                pstmt.setString(5, email);
                pstmt.setString(6, department);

                int rows = pstmt.executeUpdate();

                if (rows > 0) {
                    System.out.println("Manager added successfully.");
                } else {
                    System.out.println("Unable to add Manager.");
                }

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            manFrame.setVisible(true);
            frame.dispose();

        });
        panel.add(submitButton);

        panel.setBackground(new Color(254, 251, 246));
        panel.setBorder(new EmptyBorder(50, 50, 50, 50));

        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1100,750));
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void editManager() throws SQLException {
        manFrame.setVisible(false);

        JFrame frame = new JFrame("Edit Manager");

        JLabel label = new JLabel("Enter manager id");
        label.setFont(new Font("Times New Roman", Font.BOLD, 20));
        label.setBounds(250,200,200,50);
        frame.add(label);

        JTextField idVal = new JTextField();
        idVal.setFont(new Font("Times New Roman", Font.BOLD, 20));
        idVal.setBounds(500,200,200,50);
        frame.add(idVal);
        idVal.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        backButton.setBounds(275, 400, 150,40);
        backButton.setFocusPainted(false);

        backButton.addActionListener(actionListener -> {
            manFrame.setVisible(true);
            frame.dispose();

        });
        frame.add(backButton);

        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        submitButton.setBounds(525, 400, 150,40);
        submitButton.setFocusPainted(false);

        submitButton.addActionListener(actionEvent -> {
            JdbcConnector jdbcConnector = new JdbcConnector();
            jdbcConnector.connect();
            Connection conn = jdbcConnector.getConnection();
            jdbcConnector.connect();
            int id = Integer.parseInt(idVal.getText());
            String q = "select * from manager where id = ?";
            PreparedStatement pstmt = null;
            ResultSet resultSet = null;
            try {
                pstmt = conn.prepareStatement(q);
                pstmt.setInt(1, id);
                resultSet = pstmt.executeQuery();
                if (resultSet.next()) {
                    System.out.println(resultSet.getString(2));
                    editManagerHelper(id, frame);
                }
                else{
                    JFrame popup = new JFrame("Invalid ID");
                    JLabel popupMsg = new JLabel("The ID you entered is invalid.");
                    popupMsg.setBounds(20,10,300,50);
                    popupMsg.setFont(new Font("Times New Roman", Font.PLAIN, 20));
                    popup.add(popupMsg);

                    JButton button = new JButton("OK");
                    button.setBounds(120,60,70,20);
                    button.setFont(new Font("Times New Roman", Font.PLAIN, 20));
                    button.addActionListener(actionEvent2 -> {
                        popup.dispose();
                    });
                    popup.add(button);

                    popup.setLayout(null);
                    popup.setSize(350, 150);
                    popup.setVisible(true);

                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        });

        frame.add(submitButton);

        frame.setLayout(null);
        frame.setSize(new Dimension(1100,750));
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }
    public void editManagerHelper(int id, JFrame parentFrame) throws SQLException {
        JFrame frame = new JFrame("Edit Manager");
        JPanel panel=new JPanel();
        JdbcConnector jdbcConnector = new JdbcConnector();
        jdbcConnector.connect();
        Connection conn = jdbcConnector.getConnection();
        jdbcConnector.connect();
        String q = "select * from manager where id = ?";
        PreparedStatement pstmt = null;
        ResultSet resultSet = null;
        try {
            pstmt = conn.prepareStatement(q);
            pstmt.setInt(1, id);
            resultSet = pstmt.executeQuery();
            resultSet.next();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        JLabel unameLabel = new JLabel("Username");
        unameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField unameVal = new JTextField(resultSet.getString(1));
        unameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField passVal = new JTextField(resultSet.getString(2));
        passVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel nameLabel = new JLabel("Name");
        nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField nameVal = new JTextField(resultSet.getString(4));
        nameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel emailLabel = new JLabel("Email");
        emailLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField emailVal = new JTextField(resultSet.getString(5));
        emailVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel deptLabel = new JLabel("Email");
        deptLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField deptVal = new JTextField(resultSet.getString(6));
        deptVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        panel.add(unameLabel);
        panel.add(unameVal);
        panel.add(passLabel);
        panel.add(passVal);
        panel.add(nameLabel);
        panel.add(nameVal);
        panel.add(emailLabel);
        panel.add(emailVal);
        panel.add(deptLabel);
        panel.add(deptVal);

        GridLayout cardLayout = new GridLayout(0, 2);
        cardLayout.setHgap(60);
        cardLayout.setVgap(40);
        panel.setLayout(cardLayout);

        panel.setSize(1000, 400);
        panel.setBackground(new Color(166, 209, 230));
        panel.setBorder(new EmptyBorder(20, 50, 20, 50));

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        backButton.setBounds(450, 30, 200,50);
        backButton.setFocusPainted(false);

        backButton.addActionListener(actionListener -> {
            frame.dispose();
            manFrame.setVisible(true);
        });
        panel.add(backButton);

        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        submitButton.setBounds(450, 30, 200,50);
        submitButton.setFocusPainted(false);

        submitButton.addActionListener(actionListener -> {
            PreparedStatement ps  = null;
            String uname = unameVal.getText();
            String pass = passVal.getText();
            String name = nameVal.getText();
            String email = emailVal.getText();
            String department = deptVal.getText();
            String query = "update manager set username = ?, password = ?, name = ?, email = ?, department = ? where id = ?";
            try {
                ps = conn.prepareStatement(query);
                ps.setString(1, uname);
                ps.setString(2, pass);
                ps.setString(3, name);
                ps.setString(4, email);
                ps.setString(5, department);
                ps.setInt(6, id);
                ps.executeUpdate();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            manFrame.setVisible(true);
            frame.dispose();

        });
        panel.add(submitButton);

        panel.setBackground(new Color(254, 251, 246));
        panel.setBorder(new EmptyBorder(50, 50, 50, 50));

        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1100,750));
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        parentFrame.dispose();

    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void deleteManager(){
        manFrame.setVisible(false);

        JFrame frame = new JFrame("Delete Manager");

        JLabel label = new JLabel("Enter manager id");
        label.setFont(new Font("Times New Roman", Font.BOLD, 20));
        label.setBounds(250,200,200,50);
        frame.add(label);

        JTextField idVal = new JTextField();
        idVal.setFont(new Font("Times New Roman", Font.BOLD, 20));
        idVal.setBounds(500,200,200,50);
        frame.add(idVal);
        idVal.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        backButton.setBounds(275, 400, 150,40);
        backButton.setFocusPainted(false);

        backButton.addActionListener(actionListener -> {
            manFrame.setVisible(true);
            frame.dispose();

        });
        frame.add(backButton);

        JButton submitButton = new JButton("Delete");
        submitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        submitButton.setBounds(525, 400, 150,40);
        submitButton.setFocusPainted(false);

        submitButton.addActionListener(actionEvent -> {
            JdbcConnector jdbcConnector = new JdbcConnector();
            jdbcConnector.connect();
            Connection conn = jdbcConnector.getConnection();
            jdbcConnector.connect();
            int id = Integer.parseInt(idVal.getText());
            String q = "select * from manager where id = ?";
            PreparedStatement pstmt = null;
            ResultSet resultSet = null;
            try {
                pstmt = conn.prepareStatement(q);
                pstmt.setInt(1, id);
                resultSet = pstmt.executeQuery();
                if (resultSet.next()) {
                    System.out.println(resultSet.getString(2));

                    String deleteQuery = "delete from manager where id = ?";
                    pstmt = conn.prepareStatement(deleteQuery);
                    pstmt.setInt(1, id);
                    pstmt.executeUpdate();
                    manFrame.setVisible(true);
                    frame.dispose();

                }
                else{
                    JFrame popup = new JFrame("Invalid ID");
                    JLabel popupMsg = new JLabel("The ID you entered is invalid.");
                    popupMsg.setBounds(20,10,300,50);
                    popupMsg.setFont(new Font("Times New Roman", Font.PLAIN, 20));
                    popup.add(popupMsg);

                    JButton button = new JButton("OK");
                    button.setBounds(120,60,70,20);
                    button.setFont(new Font("Times New Roman", Font.PLAIN, 20));
                    button.addActionListener(actionEvent2 -> {
                        popup.dispose();
                    });
                    popup.add(button);

                    popup.setLayout(null);
                    popup.setSize(350, 150);
                    popup.setVisible(true);

                }
                resultSet.close();
                pstmt.close();
                conn.close();
                jdbcConnector.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        });

        frame.add(submitButton);

        frame.setLayout(null);
        frame.setSize(new Dimension(1100,750));
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);

    }
}


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel and Tour Website - Login</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-image: url('travel.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        height: 100vh;
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
    }

        .login-container {
            width: 300px;
            margin: auto;
            margin-top: 100px;
            border: 1px solid black;
            padding: 20px;
            border-radius: 5px;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group label {
            display: block;
            margin-bottom: 5px;
        }
        .input-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .input-group button {
            width: 100%;
            padding: 8px;
            border: none;
            background-color: #4CAF50;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        .forgot-password {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="login.php" method="post">
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="input-group">
                <button type="button" onclick="redirectToPage()">Login</button>
            </div>
        </form>
        <div class="forgot-password">
            <a href="/forgot_password">Forgot Password?</a>
        </div>
        <p>Don't have an account? <a href="signup.html">Sign up</a></p>
    </div>

    <script>
        function redirectToPage() {
            // Perform necessary authentication checks
            // Redirect to another webpage upon successful login
            window.location.href = "project.html"; // Replace '/welcome.html' with the path of the desired webpage
        }
    </script>
</body>
</html>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet" />
</head>
<body>
    <nav>
        <div class="container">
            <div class="nav-wrapper">
                <a href="#" class="nav-brand">
                    <img src="img.jpg" alt="travel logo" />
                </a>
                <div class="nav-menu-wrapper">
                    <div class="navbar-menu-header">
                        <p class="navbar-menu-title">Menu</p>
                        <a href="#" data-dismiss="navbar-menu" class="navbar-menu-close">&times;</a>
                    </div>
                    <ul class="nav-menu">
                        <li><a href="#" data-toggle="navbar-submenu" data-target="#destination">Destinations <i class="ri-arrow-down-s-line"></i></a>
                            <div class="navbar-submenu-wrapper" >
                                <div class="navbar-submenu-menu-wrapper" id="destination">
                                    <div class="navbar-submenu-header">
                                        <a href="#" data-dismiss="navbar-submenu" class="navbar-submenu-back">Back</a>
                                        <a href="#" data-dismiss="navbar-menu" class="navbar-menu-close">&times;</a>
                                    </div>
                                    <ul class="navbar-submenu-menu">
                                        <li><a href="#" class="active" data-toggle="navbar-submenu-content navbar-submenu" data-target="#destination-asia">Andhra pradesh <i class="ri-arrow-right-s-line"></i></a></li>
                        
                                        <li><a href="#"  data-toggle="navbar-submenu-content navbar-submenu" data-target="#destination-europe">Karnataka <i class="ri-arrow-right-s-line"></i></a></li>
        
                                        <li><a href="#"  data-toggle="navbar-submenu-content navbar-submenu" data-target="#destination-kerala">Kerala <i class="ri-arrow-right-s-line"></i></a></li>
                                    </ul>
                                </div>    
                                <div class="navbar-submenu-content-wrapper active" id="destination-asia">
                                    <div class="navbar-submenu-header" id="destination-asia">
                                        <a href="#" data-dismiss="navbar-submenu" class="navbar-submenu-back">Back</a>
                                        <a href="#" data-dismiss="navbar-menu" class="navbar-menu-close">&times;</a>
                                    </div>
                                   <div class="navbar-submenu-content-title">Andhrapradeh</div>
                                     <ul class="navbar-submenu-content" id="">
                                        <li><a href="rishikondabeach.html">Rishikonda Beach</a></li>
                                        <li><a href="tirumala.html">Tirumala</a></li>
                                        <li><a href="arakuvalley.html">Araku Valley</a></li>
                
                                        <br>
                                        <li><a href="suryalankabeach.html">Surya Lanka Beach</a></li>
                                        <li><a href="srisailam.html">Srisailam</a></li>
                                        <li><a href="anathagirihills.html">Lambasingi HillStation</a></li>
                                    
                                        <br>
                                        <li><a href="mayapadubeach.html">Mayapaadu Beach</a></li>
                                        <li><a href="kanakadurgamma.html">kanakaDurgamma</a></li>
                                        <li><a href="horselyhills.html">Horsely Hills</a></li>
                                        <br>
                                     </ul>
                                        
                                        </div>
                                        <div class="navbar-submenu-content-wrapper " id="destination-europe">
                                            <div class="navbar-submenu-header" id="destination-europe">
                                                <a href="#" data-dismiss="navbar-submenu" class="navbar-submenu-back">Back</a>
                                                <a href="#" data-dismiss="navbar-menu" class="navbar-menu-close">&times;</a>
                                            </div>
                                            <div class="navbar-submenu-content-title">Karnataka</div>
                                            <ul class="navbar-submenu-content" id="">
                                                <li><a href="bangalore.html">Bangalore</a></li>
                                                <li><a href="mysore.html">Mysore</a></li>
                                                <li><a href="coorg.html">Coorg</a></li>
                                                <li><a href="gokarna.html">Gokarna</a></li>
                                                <li><a href="hampi.html">Hampi</a></li>
                                                <li><a href="mangalore.html">Mangalore</a></li>
                                                
                                            </ul>
                                            </div>
                                                <div class="navbar-submenu-content-wrapper" id="destination-kerala">
                                                    <div class="navbar-submenu-header">
                                                        <a href="#" data-dismiss="navbar-submenu" class="navbar-submenu-back">Back</a>
                                                        <a href="#" data-dismiss="navbar-menu" class="navbar-menu-close">&times;</a>
                                                    </div>
                                                    <div class="navbar-submenu-content-title">Kerala</div>
                                            <ul class="navbar-submenu-content" id="">
                                                <li><a href="kovalam.html">Kovalam Beach</a></li>
                                                <li><a href="guruvayur.html">Guruvayur Temple</a></li>
                                                <li><a href="silent.html">Silent Valley</a></li>
                                                <br>
                                                <li><a href="cherai.html">Cherai Beach</a></li>
                                                <li><a href="padmanabhaswamy.html">Shree Padmanabhaswamy Temple</a></li>
                                                <li><a href="virgin.html">Virgin Valley</a></li>
                                                <br>
                                                <li><a href="varkala.html">Varkala Beach</a></li>
                                                <li><a href="sabarimala.html">Sabarimala Temple</a></li>
                                                <li><a href="palakkayam.html">PalakkayamThattu Valley</a></li>    
                                            </ul>
                                    </div>
                                    
                            </div>
                            
                        </li>
                        <li><a href="aboutus.html">About us</a></li>
                        <li><a href="contactus.html">Contact Us</a></li>
                    </ul>
                </div> 
                <a href="#" class="navbar-toggle">
                    <i class="ri-menu-line"></i>
                </a>   
            </div>
        </div>
    </nav>  
    <header>
        <div class="container">
            <div class="header-image">
                <img class="active" src="arakuvalley.jpg" alt="carousel" />
                <img src="tirumala.jpg" alt="carousel" />
                <img src="hero-bg-3.webp" alt="carousel" />
            </div>
            <div class="header-wrapper">
                <h2 class="header-title">Experiencing Local Culture: Immersive Travel Experiences</h2>
                <p class="header-description">Immerse yourself in the rich tapestry of various cultures as we explore the customs, traditions, and heritage of different regions across South states of India.</p>
                
            </div>
            <div class="header-image-indicator">
                <a href="#" class="active"></a>
                <a href="#"></a>
                <a href="#"></a>
            </div>
        </div>
    </header>
    <section>
        <div class="container">
            <div class="feature-wrapper">
                <div>
                    <div class="feature-icon">
                        <i class="ri-plane-line"></i>
                    </div>
                    <h3 class="feature-title">Customizable Tours</h3>
                    <p class="feature-description">Create your own itinerary and choose the destinations, activities, and experiences that match your interests and preferences.</p>
                </div>
                <div>
                    <div class="feature-icon">
                        <i class="ri-book-mark-line"></i>
                    </div>
                    <h3 class="feature-title">Customizable Tours</h3>
                    <p class="feature-description">Create your own itinerary and choose the destinations, activities, and experiences that match your interests and preferences.</p>
                </div>
                <div>
                    <div class="feature-icon">
                        <i class="ri-time-line"></i>
                    </div>
                    <h3 class="feature-title">Customizable Tours</h3>
                    <p class="feature-description">Create your own itinerary and choose the destinations, activities, and experiences that match your interests and preferences.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="destination">
        <div class="container">
            <h2 class="destination-title">Top Destinations</h2>
            <div class="destination-wrapper">
                <a href="#" class="slider-arrow prev" data-slide="prev" data-target="#destination-list"><i class="ri-arrow-left-s-line"></i></a>
                <a href="#" class="slider-arrow next" data-slide="next" data-target="#destination-list"><i class="ri-arrow-right-s-line"></i></a>
                <div class="destination-list" id="destination-list">
                    <div>
                        <div class="destination-list-top">
                            <img src="Talakona.jpg" />
                            <a class="destinations-list-top-favourite">
                                <i class="ri-heart-3-line"></i>
                            </a>
                            <span class="destinations-list-top-tag">Popular</span>
                        </div>
                        <div class="destination-list-content">
                            <div class="destination-list-content-location">
                                <i class="ri-global-line"></i>
                               Talakona
                            </div>
                            <a class="destination-list-content-title" href="#">Explore the Magic of Talakona</a>
                            <div class="destination-list-content-rating">
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-half-fill"></i>
                            </div>
                            <div class="destination-list-content-price">
                                from <span>rs:2000</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="destination-list-top">
                            <img src="srikalahasthi.jpg" />
                        </div>
                        <div class="destination-list-content">
                            <div class="destination-list-content-location">
                                <i class="ri-global-line"></i>
                                Srikalahasthi
                            </div>
                            <a class="destination-list-content-title" href="#">Explore the Magic of Srikalahasthi</a>
                            <div class="destination-list-content-rating">
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-half-fill"></i>
                            </div>
                            <div class="destination-list-content-price">
                                from <span>rs:2000</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="destination-list-top">
                            <img src="mantralayam.jpg" />
                        </div>
                        <div class="destination-list-content">
                            <div class="destination-list-content-location">
                                <i class="ri-global-line"></i>
                                   Mantralayam
                            </div>
                            <a class="destination-list-content-title" href="#">Explore the Magic of Mantralayam</a>
                            <div class="destination-list-content-rating">
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-half-fill"></i>
                            </div>
                            <div class="destination-list-content-price">
                                from <span>rs:2000</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="destination-list-top">
                            <img src="lepakshi.jpg" />
                        </div>
                        <div class="destination-list-content">
                            <div class="destination-list-content-location">
                                <i class="ri-global-line"></i>
                                Lepakshi
                            </div>
                            <a class="destination-list-content-title" href="#">Explore the Magic of Lepakshi</a>
                            <div class="destination-list-content-rating">
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-half-fill"></i>
                            </div>
                            <div class="destination-list-content-price">
                                from <span>rs:2000</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="destination-list-top">
                            <img src="rajamundry.jpg" />
                        </div>
                        <div class="destination-list-content">
                            <div class="destination-list-content-location">
                                <i class="ri-global-line"></i>
                                Rajamundry
                            </div>
                            <a class="destination-list-content-title" href="#">Explore the Magic of Rajamundry</a>
                            <div class="destination-list-content-rating">
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-half-fill"></i>
                            </div>
                            <div class="destination-list-content-price">
                                from <span>rs:3000</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="destination-list-top">
                            <img src="Ahobilam.webp" />
                        </div>
                        <div class="destination-list-content">
                            <div class="destination-list-content-location">
                                <i class="ri-global-line"></i>
                                Ahobilam
                            </div>
                            <a class="destination-list-content-title" href="#">Explore the Magic of Ahobilam</a>
                            <div class="destination-list-content-rating">
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-fill"></i>
                                <i class="ri-star-half-fill"></i>
                            </div>
                            <div class="destination-list-content-price">
                                from <span>rs:3000</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="testimonial">
        <div class="container">
            <h2 class="section-title">Join with the Yatra, Read Our Reviews</h2>
            <div class="testimonial-wrapper">
                <div class="testimonial-list">
                    <div>
                        <img src="" class="testimonial-user-image"/>
                        <p class="testimonial-content"> "Booking a trip with Yatra was the best decision I made for my vacation. The team was incredibly knowledgeable about the destination and helped me create an itinerary that perfectly suited my interests. From the breathtaking scenic views to the carefully curated local experiences, every moment of my trip was unforgettable. The accommodations were top-notch, and the entire journey was seamless and stress-free. I can't wait to plan my next adventure with Yatra. Highly recommended!"</p>
                        <div class="testimonial-user-name">Charitha</div>
                        <div class="testimonial-user-job">Explorer</div>
                    </div>
                    <div>
                        <img src="" class="testimonial-user-image"/>
                        <p class="testimonial-content">"From start to finish, our experience with Yatra was exceptional. Their attention to detail and personalized service made our trip to Coorg truly unforgettable. The local guides were knowledgeable and passionate about sharing their culture and history with us. The seamless organization and thoughtful recommendations truly made this the trip of a lifetime. We can't wait to explore another destination with them soon!"</p>
                        <div class="testimonial-user-name">Gowri</div>
                        <div class="testimonial-user-job">Explorer</div>
                    </div>
                    <div>
                        <img src="image.jpg" class="testimonial-user-image"/>
                        <p class="testimonial-content">"Thank you to the amazing team at Yatra for organizing a seamless and unforgettable vacation for us. The kids were thrilled with the specially tailored activities, and we were blown away by the stunning accommodations and the breathtaking views. We felt completely at ease throughout the entire journey, knowing that every aspect of our trip was expertly taken care of. We will definitely be returning for our next tour"</p>
                        <div class="testimonial-user-name">Yamuna</div>
                        <div class="testimonial-user-job">Explorer</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <div class="footer-top">
                <a href="#" class="footer-logo"><img src="img.jpg" /></a>
                <div class="footer-social">
                    <a href="#"><i class="ri-facebook-fill"></i></a>
                    <a href="#"><i class="ri-instagram-fill"></i></a>
                    <a href="#"><i class="ri-twitter-fill"></i></a>
                    <a href="#"><i class="ri-linkedin-fill"></i></a>
                </div>
            </div>
            <div class="footer-links">
                <div>
                    <div class="footer-links-title">Company</div>
                    <ul class="footer-links-list">
                        <li><a href="#">About</a></li>
                        <li><a href="#">Terms & Condition</a></li>
                        <li><a href="#">Privacy & Policy</a></li>
                    </ul>
                </div>
                <div>
                    <div class="footer-links-title">Details</div>
                    <ul class="footer-links-list">
                        <li><a href="#">Services</a></li>
                        <li><a href="#">Contact |Info</a></li>
                        <li><a href="#">Tour Details</a></li>
                    </ul>
                </div>
                <div>
                    <div class="footer-links-title">Price Details</div>
                    <ul class="footer-links-list">
                        <li><a href="#">Refund Info</a></li>
                        <li><a href="#">Travels</a></li>
                        <li><a href="#">Privacy & Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>Copyright © YATRA TRAVELS. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
    <script src="main.js"></script>  
</body>
</html>
